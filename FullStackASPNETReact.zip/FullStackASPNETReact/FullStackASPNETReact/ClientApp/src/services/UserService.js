﻿import axios from 'axios';
import config from '../config';

class UserService {
    async GetUsers() {
        return await axios.get(config.apiAddress + '/user');
    }
    async GetUser(id) {
        return await axios.get(config.apiAddress + '/user/' + id);
    }
    async AddUser(user) {
        return await axios.post(config.apiAddress + '/user', user);
    }
}

const service = new UserService();
export default service;