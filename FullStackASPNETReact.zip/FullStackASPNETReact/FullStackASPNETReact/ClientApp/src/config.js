﻿const Config = {
    apiAddress:'/api'
}

export default Config;