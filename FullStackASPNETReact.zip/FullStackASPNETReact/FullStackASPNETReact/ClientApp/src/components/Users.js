﻿import React, { Component } from 'react';
import { Table } from 'reactstrap';

import UserService from '../services/UserService';

export class Users extends Component {
    constructor(props) {
        super(props);
        this.state = {
            users: []
        }
    }

    componentDidMount() {
        UserService.GetUsers().then(res => {
            this.setState({ users: res.data });
        })
    }

    render() {
        return(
            <div>
                <Table striped>
                    <thead>
                        <tr>
                            <th>UserId</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.users.map((item, i) => {
                                return <tr key={i}>
                                    <td>{item.userId}</td>
                                    <td>{item.name}</td>
                                    <td>{item.contact}</td>
                                    <td>{item.address}</td>
                                </tr>
                            })
                        }
                    </tbody>
                </Table>
            </div>
        )
    }
}